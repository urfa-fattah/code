#include <stdio.h>
int main() {
    int n = 5, i, j;
    // scanf("%d", &n);  // uncomment to read n from user
    for (i = 1; i <= n; i++) {
        for (j = 1; j <= n; j++) {
            if (i == 1 || i == n || j == 1 || j == n) printf("* ");
            else printf("  ");
        }
        printf("\n");
    }
    return 0;
}
