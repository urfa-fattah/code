#include <stdio.h>
int main() {
    int n = 5, i, j;
    // scanf("%d", &n);  // uncomment to read n from user
    for (i = 0; i < n; i++) {
        for (j = 0; j <= i; j++) printf("%c ", 'A' + i);
        printf("\n");
    }
    return 0;
}
