#include <stdio.h>
int main() {
    int n = 5, i, j;
    // scanf("%d", &n);  // uncomment to read n from user
    for (i = n; i >= 1; i--) {
        for (j = 1; j <= i; j++) printf("%d ", i);
        printf("\n");
    }
    return 0;
}
