#include <stdio.h>
int main() {
    int n = 5, i, j;
    // scanf("%d", &n);  // uncomment to read n from user
    for (i = n; i >= 1; i--) {
        for (j = 1; j <= n - i; j++) printf(" ");
        for (j = 1; j <= 2 * i - 1; j++) printf("*");
        printf("\n");
    }
    return 0;
}
