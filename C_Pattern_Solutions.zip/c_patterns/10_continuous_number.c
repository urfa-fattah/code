#include <stdio.h>
int main() {
    int n = 5, i, j;
    // scanf("%d", &n);  // uncomment to read n from user
    int num = 1;
    for (i = 1; i <= n; i++) {
        for (j = 1; j <= i; j++) printf("%d ", num++);
        printf("\n");
    }
    return 0;
}
