#include <stdio.h>

int main() {
    int n, i = 1;
    long sum = 0;

    printf("Enter value of n: ");
    scanf("%d", &n);

    do {
        sum += i * i * i;
        i++;
    } while (i <= n);

    printf("Sum of cubes = %ld\n", sum);
    return 0;
}
