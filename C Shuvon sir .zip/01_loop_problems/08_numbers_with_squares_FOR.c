#include <stdio.h>

int main() {
    int n, i;

    printf("Enter value of n: ");
    scanf("%d", &n);

    printf("Number\tSquare\n");
    for (i = 1; i <= n; i++)
        printf("%d\t%d\n", i, i * i);

    return 0;
}
