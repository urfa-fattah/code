#include <stdio.h>

int main() {
    int num, i = 1;

    printf("Enter a number: ");
    scanf("%d", &num);

    printf("Multiples between 1 and 100:\n");
    while (i <= 100) {
        if (i % num == 0)
            printf("%d ", i);
        i++;
    }
    printf("\n");

    return 0;
}
