#include <stdio.h>

int main() {
    int i, cnt = 0;

    for (i = 1; i <= 100; i++) {
        if (i % 3 == 0) {
            printf("%d ", i);
            cnt++;
        }
    }
    printf("\nTotal: %d\n", cnt);

    return 0;
}
