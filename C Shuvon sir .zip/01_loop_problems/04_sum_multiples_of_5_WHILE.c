#include <stdio.h>

int main() {
    int i = 1, sum = 0;

    while (i <= 100) {
        if (i % 5 == 0)
            sum += i;
        i++;
    }
    printf("Sum = %d\n", sum);

    return 0;
}
