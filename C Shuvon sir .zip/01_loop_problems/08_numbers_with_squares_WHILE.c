#include <stdio.h>

int main() {
    int n, i = 1;

    printf("Enter value of n: ");
    scanf("%d", &n);

    printf("Number\tSquare\n");
    while (i <= n) {
        printf("%d\t%d\n", i, i * i);
        i++;
    }

    return 0;
}
