#include <stdio.h>

int main() {
    int num, i = 1;

    printf("Enter a number: ");
    scanf("%d", &num);

    printf("Multiples between 1 and 100:\n");
    do {
        if (i % num == 0)
            printf("%d ", i);
        i++;
    } while (i <= 100);
    printf("\n");

    return 0;
}
