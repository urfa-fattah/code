#include <stdio.h>

int main() {
    int num, i;

    printf("Enter a number: ");
    scanf("%d", &num);

    printf("Multiples between 1 and 100:\n");
    for (i = 1; i <= 100; i++) {
        if (i % num == 0)
            printf("%d ", i);
    }
    printf("\n");

    return 0;
}
