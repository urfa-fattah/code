#include <stdio.h>

int main() {
    int i = 1, sum = 0;

    do {
        if (i % 5 == 0)
            sum += i;
        i++;
    } while (i <= 100);
    printf("Sum = %d\n", sum);

    return 0;
}
