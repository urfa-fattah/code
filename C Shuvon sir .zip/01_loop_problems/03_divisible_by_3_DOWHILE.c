#include <stdio.h>

int main() {
    int i = 1, cnt = 0;

    do {
        if (i % 3 == 0) {
            printf("%d ", i);
            cnt++;
        }
        i++;
    } while (i <= 100);
    printf("\nTotal: %d\n", cnt);

    return 0;
}
