#include <stdio.h>

int main() {
    int n, i = 1;
    long sum = 0;

    printf("Enter value of n: ");
    scanf("%d", &n);

    while (i <= n) {
        sum += i * i;
        i++;
    }

    printf("Sum of squares = %ld\n", sum);
    return 0;
}
