#include <stdio.h>

int main() {
    int a, b, i, temp, sum = 0;

    printf("Enter a and b: ");
    scanf("%d %d", &a, &b);

    if (a > b) {
        temp = a;
        a = b;
        b = temp;
    }

    i = a;
    while (i <= b) {
        sum += i;
        i++;
    }

    printf("Sum = %d\n", sum);
    return 0;
}
