#include <stdio.h>

int main() {
    int n, i;
    long sum = 0;

    printf("Enter value of n: ");
    scanf("%d", &n);

    for (i = 1; i <= n; i++)
        sum += i * i * i;

    printf("Sum of cubes = %ld\n", sum);
    return 0;
}
