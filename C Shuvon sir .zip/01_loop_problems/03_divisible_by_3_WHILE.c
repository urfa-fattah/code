#include <stdio.h>

int main() {
    int i = 1, cnt = 0;

    while (i <= 100) {
        if (i % 3 == 0) {
            printf("%d ", i);
            cnt++;
        }
        i++;
    }
    printf("\nTotal: %d\n", cnt);

    return 0;
}
