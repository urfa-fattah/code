# C Programming Lab - for Loop Practice Problems (with while & do-while)

## 01_loop_problems (24 files)
All 8 problems from the lab sheet, each done 3 ways: FOR, WHILE, DOWHILE.

01. Print Multiplication Table
02. Print Multiples of a Number
03. Count Numbers Divisible by 3
04. Sum of Multiples of 5
05. Sum of Squares
06. Sum of Cubes
07. Sum of Numbers in a Range (a to b)
08. Print Numbers with Their Squares

## 02_increment_decrement_problems

### output_prediction (12 files)
Short programs built around tricky ++/-- behavior - the "predict the
output before you run it" type questions that show up a lot in exams.
Covers: post vs pre increment/decrement, mixed expressions like
a++ + ++a, printf argument order, increment inside loop conditions,
array indexing, short-circuit && skipping a side effect, ternary,
and nested loops combining increment/decrement.

A couple of these (03, 04, 05) depend on compiler evaluation order -
that's flagged in a comment inside the file, since it's worth knowing
even though these questions are still common in exams.

### low_level_basics (6 files)
Simpler, first-week-of-class level programs:
01. Basic increment/decrement demo (no loop, just x++ / x-- / ++x / --x)
02. Print 1 to n
03. Print n down to 1
04. Count even and odd numbers up to n
05. Print A to Z using char increment
06. Swap two numbers without a third variable

## Compiling
gcc filename.c -o output

All 42 files compiled and ran without errors before packaging.
