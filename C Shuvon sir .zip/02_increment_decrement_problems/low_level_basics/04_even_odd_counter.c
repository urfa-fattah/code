#include <stdio.h>

int main() {
    int n, i, evenCount = 0, oddCount = 0;

    printf("Enter n: ");
    scanf("%d", &n);

    for (i = 1; i <= n; i++) {
        if (i % 2 == 0)
            evenCount++;
        else
            oddCount++;
    }

    printf("Even: %d, Odd: %d\n", evenCount, oddCount);
    return 0;
}
