#include <stdio.h>

/* Order of evaluation for a++ and ++a on the two sides of + is not
   fixed by the C standard, so this is technically compiler-dependent.
   GCC usually gives a = 7, c = 12. Trace it yourself first. */
int main() {
    int a = 5;
    int c = a++ + ++a;
    printf("a = %d\n", a);
    printf("c = %d\n", c);
    return 0;
}
