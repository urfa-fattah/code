#include <stdio.h>

int main() {
    int i, j, total = 0;

    for (i = 1; i <= 3; i++) {
        j = 3;
        while (j > 0) {
            total++;
            j--;
        }
    }
    printf("total = %d\n", total);
    return 0;
}
