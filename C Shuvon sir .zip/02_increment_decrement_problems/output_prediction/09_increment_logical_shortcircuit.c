#include <stdio.h>

/* && only checks the right side if the left side is true.
   a is 0 here, so b++ never actually runs. */
int main() {
    int a = 0, b = 5;

    if (a++ && b++)
        printf("condition true\n");
    else
        printf("condition false\n");

    printf("a = %d\n", a);
    printf("b = %d\n", b);

    return 0;
}
