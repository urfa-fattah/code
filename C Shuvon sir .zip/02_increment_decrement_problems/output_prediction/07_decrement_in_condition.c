#include <stdio.h>

int main() {
    int n = 5, count1 = 0;
    while (n-- > 0)
        count1++;
    printf("count1 = %d, n = %d\n", count1, n);

    int m = 5, count2 = 0;
    while (--m > 0)
        count2++;
    printf("count2 = %d, m = %d\n", count2, m);

    return 0;
}
