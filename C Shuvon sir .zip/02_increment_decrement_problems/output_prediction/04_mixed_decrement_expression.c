#include <stdio.h>

/* Same idea as the increment version, just with -- and subtraction. */
int main() {
    int b = 5;
    int d = b-- - --b;
    printf("b = %d\n", b);
    printf("d = %d\n", d);
    return 0;
}
