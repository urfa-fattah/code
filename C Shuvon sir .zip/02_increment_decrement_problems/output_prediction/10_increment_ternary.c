#include <stdio.h>

int main() {
    int a = 5, b = 10;
    int result = (a < b) ? a++ : ++b;

    printf("result = %d\n", result);
    printf("a = %d\n", a);
    printf("b = %d\n", b);

    return 0;
}
