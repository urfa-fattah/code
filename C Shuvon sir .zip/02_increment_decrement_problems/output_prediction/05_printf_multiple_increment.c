#include <stdio.h>

/* Another compiler-dependent classic - printf doesn't guarantee
   argument evaluation order. Still shows up in exams a lot. */
int main() {
    int i = 1;
    printf("%d %d %d\n", i, ++i, i++);
    printf("final i = %d\n", i);
    return 0;
}
