#include <stdio.h>

int main() {
    int i = 0, sum = 0;

    while (i < 5) {
        sum += i++;
        sum += --i;   /* cancels part of the i++ above - watch closely */
        i++;
    }

    printf("i = %d\n", i);
    printf("sum = %d\n", sum);
    return 0;
}
