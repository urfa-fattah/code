#include <stdio.h>

int main() {
    int i, count1 = 0, count2 = 0;

    for (i = 0; i < 5; i++)
        count1++;

    i = 0;
    while (i++ < 5)
        count2++;

    printf("count1 = %d\n", count1);
    printf("count2 = %d\n", count2);
    return 0;
}
