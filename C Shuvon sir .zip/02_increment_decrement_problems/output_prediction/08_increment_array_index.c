#include <stdio.h>

int main() {
    int arr[5] = {10, 20, 30, 40, 50};
    int i = 0;

    printf("%d\n", arr[i++]);
    printf("%d\n", arr[i++]);
    printf("%d\n", arr[++i]);
    printf("i is now %d\n", i);

    return 0;
}
