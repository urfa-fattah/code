/* Check whether three angles can form a valid triangle. */
#include <stdio.h>

int main(void)
{
	float A, B, C;

	printf("Enter the three angles of the triangle: ");
	if (scanf("%f %f %f", &A, &B, &C) != 3) {
		printf("Invalid input.\n");
		return 1;
	}

	if (A>0 && B>0 && C>0 &&
		A + B + C == 180) {
		printf("The triangle is valid.\n");
	} else {
		printf("The triangle is not valid.\n");
	}

	return 0;
}
