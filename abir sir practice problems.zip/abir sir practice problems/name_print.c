#include<stdio.h>
int main(){
    char name[100];
    printf("Enter your name: ");
    scanf("%s", name);
    printf("I am, %s!", name);
    return 0;
}