#include <stdio.h>
int main()
{
	int num, origin, rev= 0, rem;
	printf("Enter a number: ");
	scanf("%d", &num);
	origin = num;
	while (num != 0) {
		rem = num % 10;
		rev = rev * 10 + rem;
		num /= 10;
	}
	if (origin == rev)
		printf("%d is a palindrome, because the reverse is %d \n", origin,rev);
	else
		printf("%d is not a palindrome, because the reverse is %d \n", origin,rev);

	return 0;
}
