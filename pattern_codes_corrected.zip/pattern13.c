#include<stdio.h>
int main(){
    int a[]={1, 3 , 5 , 7, 9};
    for(int i=0;i<5;i++){
        for(int j=1;j<=4-i;j++){
            printf(" ");
        }
        for(int j=1;j<=a[i];j++){
            printf("*");
        }
        printf("\n");
    }
    return 0;
}
