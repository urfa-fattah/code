#include<stdio.h>
int main(){
    int a[]={1,2,3,4,5};
    int p=1;
    for(int i=0;i<5;i++){
        for(int j=1;j<=a[i];j++){
            printf("%d ",p++);
        }
        printf("\n");

    }
    return 0;
}
