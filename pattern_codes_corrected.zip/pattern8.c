#include<stdio.h>
int main(){
    for(int i=1;i<=5;i++){
        char ch='@';
        for(int j=1;j<=i;j++){
            printf("%c ",ch+1);
            ch++;
        }
        printf("\n");
    }
    return 0;
}
