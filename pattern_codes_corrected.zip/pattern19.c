#include<stdio.h>
int main(){
    for(int i=1;i<=5;i++){
        int v=i%2;
        for(int j=1;j<=i;j++){
            printf("%d ",v);
            v=1-v;
        }
        printf("\n");
    }
    return 0;
}
